<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a href="{{route('home')}}" class="navbar-brand">Hesham</a>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item"><a href="{{route('home')}}" class="nav-link">Home</a></li>
      <li class="nav-item"><a href="{{route('designs')}}" class="nav-link">Products</a></li>
      <li class="nav-item"><a href="{{route('resume')}}" class="nav-link">About Us</a></li>
    </ul>
  </div>
</nav>

