@extends('homePage')
    
@section('title','Projects')

@section('content')
      Welcome in the Projects page!
@endsection