@extends('homePage')
    
@section('title','About Me')

@section('content')
      Hello, this is the resume page!
@endsection