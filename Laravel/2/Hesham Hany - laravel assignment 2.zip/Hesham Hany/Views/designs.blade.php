@extends('homePage')
    
@section('title','Designs')

@section('content')
      Welcome in the designs page!
@endsection