@extends('homePage')
    
@section('title','Tutorials')

@section('content')
      Welcome in the tutorials page!
@endsection